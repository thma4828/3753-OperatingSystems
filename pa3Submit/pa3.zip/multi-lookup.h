#ifndef MULTI_LOOKUP
#define MULTI_LOOKUP 

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>



#endif //MULTI_LOOKUP